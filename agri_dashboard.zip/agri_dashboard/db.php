<?php
$host = "localhost";
$db = "agri_bridge_db"; // Your database name
$user = "root";          // XAMPP default
$pass = "";              // XAMPP default is empty

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>


